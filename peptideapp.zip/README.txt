Peptide Tracker — README (v15.3)
================================
Author: M. Jones
Platform: Windows (.exe, self-contained)
License: Research Use Only — Not Medical Advice


OVERVIEW
--------
Peptide Tracker is a desktop research logging tool designed to help users maintain structured,
accurate dose logs, track vial usage, schedule injections, and document personal research notes.
The application does not provide dosing advice, clinical recommendations, or medical guidance.
It is strictly a personal research organization tool.

All data is stored locally. No internet accounts, cloud databases, or online sync are used.
Your logs, profiles, and notes remain private on your computer.


WHAT IS NEW IN v15.3
--------------------
• Notes are now displayed in a panel on the right side, under Today’s Schedule.
• Each profile has its own separate notes file.
• Notes auto-save every few seconds while typing, and also save automatically when switching profiles.
• Old floating Notes Editor window removed (interface simplified).
• Right panel layout now expands more naturally to use available space.
• Internal codebase cleaned and refactored for clearer state handling.


KEY FEATURES
------------
1. Profile-Based Tracking:
   - Each peptide or compound you are studying is stored as its own profile.
   - Profiles store vial size, BAC dilution volume, target dose, concentration, and remaining doses.
   - Switching profiles is instant and loads all profile-specific data and notes.

2. Dose Calculation:
   - Automatically computes syringe volume based on vial concentration.
   - Converts mcg → mg → mL → U-100 syringe units.
   - Shows remaining dose count based on usage history.
   - Prevents accidental overdrawing by tracking vial depletion.

3. Daily Schedule Panel:
   - Displays today's intended injection schedule.
   - Each dose automatically marks ✅ when logged.
   - Auto-refreshes at midnight to reflect a new day.

4. Logging & Data:
   - Each logged dose is written into a CSV file stored alongside the application.
   - Logs include date, time, units, mg amount, volume, and remaining doses.
   - CSV logs can be opened in Excel, Google Sheets, or statistical tools.

5. Notes (v15.3+):
   - The Notes panel is shown directly below Today’s Schedule.
   - Notes auto-save regularly and per-profile.
   - Notes are stored in readable text files: `Notes_<ProfileName>.txt`

6. Optional Email Reminders:
   - Supports Gmail reminder messages.
   - Requires a Gmail App Password (instructions below).
   - Credentials are encrypted locally (never stored or uploaded externally).


HOW TO CREATE OR LOAD A PROFILE
-------------------------------
1. Open the application.
2. Click the Profile dropdown → New Profile.
3. Enter:
   - Profile Name (ex: "BPC157")
   - Total Vial Amount (mg or mcg)
   - BAC Volume (mL used during reconstitution)
   - Target Dose per injection (mcg)
4. Click Save Profile.
5. Select profile from the dropdown to activate.


HOW TO LOG A DOSE
-----------------
1. Ensure the desired profile is active.
2. Click "Log Dose".
3. Review syringe draw volume and units displayed.
4. Confirm and save — the dose will:
   - Be appended to the log CSV.
   - Update Today’s Schedule with a ✅.
   - Reduce remaining vial doses automatically.


HOW TO RESET VIAL USAGE
-----------------------
When you reconstitute a new vial:
1. Select the profile.
2. Click "Reset Vial Usage".
3. Remaining dose count resets to full capacity.


WHERE FILES ARE STORED
----------------------
The application stores its working files in the same folder as the .exe:

profile_name.csv          — Dose history log
Notes_profile_name.txt    — Profile-specific notes
version_info.txt          — Build metadata
README.txt                — This documentation
LICENSE.txt               — License / disclaimer


NOTES AUTO-SAVE BEHAVIOR (v15.3)
--------------------------------
• Notes save automatically every 10 seconds while typing.
• Notes also save when switching to another profile.
• You do not need to press a Save button.
• Notes are stored per profile.


SETTING UP EMAIL REMINDERS (GMAIL)
----------------------------------
1. Log into https://myaccount.google.com/security
2. Enable **2-Step Verification** if not already enabled.
3. Return to the same page → Click **App Passwords**.
4. Create a new App Password:
   - App: "Mail" or "Other (Custom name)" → "Peptide Tracker"
   - Device: "Windows Computer"
5. Copy the 16-character password (no spaces).
6. In Peptide Tracker, go to:
   Settings → Email Setup
7. Enter:
   - SMTP Server: smtp.gmail.com
   - Port: 465
   - Your Gmail address
   - The App Password (NOT your regular password)
   - Recipient address (can be the same address)
8. Save settings and test.


TROUBLESHOOTING
---------------
• Email fails → Ensure you used a Gmail App Password, not your normal Gmail password.
• Doses appear wrong → Recheck vial mg and BAC mL values in the profile editor.
• Notes not appearing → Confirm the correct profile is selected.


LICENSE & USAGE TERMS
---------------------
This software is distributed strictly for **Personal Research Use Only**.
It does not provide medical guidance, dosing recommendations, or health advice.
See LICENSE.txt for full terms.


Thank You
---------
Thank you for supporting ongoing improvements to Peptide Tracker.
Your feedback directly shapes future updates.
