📘 Peptide Tracker — v15.5
Daily Injection Scheduler • Animated Syringe • Profile Manager

Author: M. Jones
Platform: Windows 10/11 (Standalone EXE)
Use: Research Use Only

🧬 Overview

Peptide Tracker v15.5 is a refined, research-oriented injection tracking system for Windows that makes managing peptides simple, accurate, and visually intuitive.

Key features:

Automated daily schedule

Animated syringe gauge with smooth fill animation

Multiple profiles for different peptides or users

Precise vial tracking & remaining mg calculation

Automatic midnight rollover

Encrypted Gmail alerts

Optional Twilio SMS support

Notes editor

Dose trend graph

Polished modern interface

Runs as a standalone .exe — no Python required

🚀 Getting Started
1. Launching the App

Double-click:

PeptideApp.exe


The splash screen appears first, then the main dashboard loads.

👤 Profiles

Use profiles to manage different peptides, cycles, or subjects.

✔ Create a New Profile

Profile → New Profile

Enter a unique name

Adjust vial/dose settings

Save the profile

✔ Switch Profiles

Use the dropdown at the top-left.

✔ Save Current Profile

Profile → Save Profile

✔ Delete Profile

Profile → Delete Profile

💉 Injection Logging & Animated Syringe

The main dashboard displays:

Today’s injection schedule

Logged (green), upcoming (blue), or missed (gray) doses

Current syringe fill using the new animated gauge

Remaining vial amount

✔ Log a Dose

Click Log Dose Now.

This will:

Animate the syringe smoothly

Record the dose in the log

Update remaining mg

Mark today’s dose complete

Refresh the schedule instantly

✔ Delete a Logged Dose

Click entry → Delete Entry
Vial amount recalculates automatically.

🧪 Vial Management

Each profile stores:

Total mg per vial

mg/mL concentration

Units per dose

Remaining mg (auto-calculated)

✔ Reset Vial

Located just above “Repeat Last Dose.”

Use when starting a new vial.

🗓️ Schedule & Midnight Auto-Rollover

Peptide Tracker updates itself when the date changes.

✔ At Midnight:

Today’s date updates

Schedule resets

All doses revert to “Upcoming”

Syringe resets to 0

Optional: auto-advance the calendar date

✔ View Other Dates

Use the calendar widget to see past or future dates.

This is for viewing only and does not change system time.

📝 Notes

Each profile includes a private notes section.

✔ Open Notes

Tools → Notes Editor

Notes auto-save.

📈 Dose Trend Graph

View your dose history visually.

✔ Open Graph

Tools → View Graph

Displays:

Injection dates

mg or unit amounts

Long-term consistency trends

📨 Email Alerts (Gmail App Password)

The app supports encrypted email alerts.

✔ Step 1 — Create a Gmail App Password

Go to Google Account

Security → App Passwords

Create a new password for “Windows Computer”

✔ Step 2 — Enter in App

Settings → Email & Alerts

The app:

Encrypts the password

Uses it only when sending alerts

Never displays it

✔ Alerts Include:

Dose reminders

Missed dose warnings

Low vial alerts

Daily or scheduled notifications

📱 SMS Alerts (Twilio)

Email-to-text gateways (e.g., AT&T) no longer work.
Peptide Tracker now uses Twilio SMS.

✔ What You Need

Twilio Account SID

Auth Token

Twilio phone number

✔ Enable

Settings → SMS (Twilio)

🧰 Tools Menu

Includes:

✓ Reset Vial
✓ Notes Editor
✓ Dose Trend Graph
✓ Open Logs Folder
✓ Export CSV
✓ About / Help

🖼️ Animated Syringe Gauge (New in v15.5)

Features:

Smooth left-to-right fill animation

Accurate units and tick marks

Fixed reversed numbers issue

Real-time dose visualization

Updates instantly when logging or deleting

⚙️ Settings

Available under Settings → Preferences

Options may include:

Email alerts on/off

SMS alerts on/off

Auto-date rollover

Default profile

Units precision/rounding

Sound & notification toggles

Graph display options

🔒 Security

Gmail & Twilio credentials are encrypted

Credentials are never shown in plaintext

App sends no data unless alerts are enabled

No cloud storage — all activity is local

📝 Version Info

v15.5 – Key Updates

✔ Animated syringe added

✔ Correct syringe unit direction

✔ Midnight rollover improved

✔ Vial tracking enhanced

✔ Twilio SMS option added

✔ Notes + profile enhancements

✔ Faster launch and cleaner UI

───────────────────────────────────────────────
LICENSE & ACTIVATION
───────────────────────────────────────────────
Free 30-day trial included.
Lifetime license: $20.00 (USD).

PayPal:  mjonesjr8@gmail.com  
Venmo:   @Morris-Jones-9

Once payment is received, you will receive an unlock key
to activate permanently.

───────────────────────────────────────────────
DATA STORAGE
───────────────────────────────────────────────
All files are saved locally in your Documents folder:
• Profiles, logs, and license data  
No data is uploaded or shared externally.


📞 Support

For help or feature requests:
📧 mjonesjr8@gmail.com

🧬 Disclaimer

Peptide Tracker is for research tracking purposes only.
It is not a medical tool and offers no medical advice.